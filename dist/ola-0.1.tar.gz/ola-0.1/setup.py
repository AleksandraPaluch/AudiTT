from setuptools import setup

setup(
    name="ola",
    version='0.1',
    description='biblioteka',
    url='',
    author='ola paluch',
    author_email='olapaluch2@gmail.com',
    license='unlicense',
    packages=['projekty'],
    zip_safe=False
)